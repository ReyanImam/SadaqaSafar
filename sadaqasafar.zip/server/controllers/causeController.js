import Cause from '../models/Cause.js';
import NGO from '../models/NGO.js';

export const createCause = async (req, res) => {
  try {
    const { title, description, goalAmount, category, endDate } = req.body;
    const ngo = await NGO.findOne({ user: req.user._id });

    if (!ngo) {
      return res.status(404).json({ message: 'NGO not found' });
    }

    const cause = await Cause.create({
      title,
      description,
      ngo: ngo._id,
      goalAmount,
      category,
      endDate
    });

    await NGO.findByIdAndUpdate(ngo._id, {
      $push: { causes: cause._id }
    });

    res.status(201).json(cause);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getCauses = async (req, res) => {
  try {
    const causes = await Cause.find()
      .populate('ngo', 'name location')
      .sort('-createdAt');
    res.json(causes);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getNGOCauses = async (req, res) => {
  try {
    const { ngoId } = req.params;
    const causes = await Cause.find({ ngo: ngoId })
      .populate('ngo', 'name location')
      .sort('-createdAt');
    res.json(causes);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};