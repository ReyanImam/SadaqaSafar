import axios from 'axios';

const API_URL = 'http://localhost:3000/api';


export const getCauses = async () => {
  const response = await axios.get(`${API_URL}/causes`);
  return response.data;
};

export const getNGOCauses = async (ngoId) => {
  const response = await axios.get(`${API_URL}/causes/ngo/${ngoId}`);
  return response.data;
};

export const createCause = async (causeData, token) => {
  const response = await axios.post(`${API_URL}/causes`, causeData, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return response.data;
};