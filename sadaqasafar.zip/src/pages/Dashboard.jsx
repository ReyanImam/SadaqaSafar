import React, { useState, useEffect } from 'react';
import { Activity, Users, DollarSign, Building2, Plus } from 'lucide-react';
import useAuthStore from '../store/authStore';
import { Navigate } from 'react-router-dom';

const Dashboard = () => {
  const { user } = useAuthStore();
  const [showCauseModal, setShowCauseModal] = useState(false);

  // Redirect if not NGO
  if (!user || user.role !== 'ngo') {
    return <Navigate to="/" />;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">NGO Dashboard</h1>
        <button 
          onClick={() => setShowCauseModal(true)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Create New Cause
        </button>
      </div>

      {/* Rest of the dashboard code remains the same */}
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-600">Total Donations</h3>
            <DollarSign className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold">₹50,000</p>
          <p className="text-sm text-gray-600 mt-2">+12% from last month</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-600">Active Causes</h3>
            <Activity className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold">12</p>
          <p className="text-sm text-gray-600 mt-2">3 pending approval</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-600">Total Donors</h3>
            <Users className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold">250</p>
          <p className="text-sm text-gray-600 mt-2">+25 this week</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-600">NGO Rating</h3>
            <Building2 className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold">4.8/5.0</p>
          <p className="text-sm text-gray-600 mt-2">Based on 120 reviews</p>
        </div>
      </div>

      {/* Active Causes */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <h2 className="text-xl font-semibold mb-4">Active Causes</h2>
        <div className="space-y-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium">Healthcare for Rural Areas</h3>
                <span className="bg-emerald-100 text-emerald-600 text-xs px-2 py-1 rounded-full">
                  Active
                </span>
              </div>
              <div className="space-y-2">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>₹70,000 raised</span>
                  <span>₹100,000 goal</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;